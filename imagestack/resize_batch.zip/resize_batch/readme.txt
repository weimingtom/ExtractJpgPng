https://code.google.com/p/imagestack/
